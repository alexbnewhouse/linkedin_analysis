NHA Pathways — interactive prototype (design review)
====================================================

Open NHA-Pathways-prototype.html in any modern browser (double-click; no
server or internet connection required — the file is fully self-contained).

What it is
----------
A working prototype of the NHA Pathways toolset, built on the LinkedIn
career-trajectory analysis (~2M profiles):

  * Stories        - guided, branching walks through a major's possibility
                     space, with NHA staff gloss at every step
  * Portal         - the explorable data engine (major picker, destination
                     fan, pathways, long view, sectors, success pillars)
  * Data & methods - dataset facts, classification tiers, validation, and
                     the project's honesty commitments

How to read the numbers
-----------------------
Every figure is badged:

  * PIPELINE DATA (green) - computed by the validated analysis pipeline
  * ILLUSTRATIVE (amber)  - placeholder showing the product shape; the
                            education-to-career analyses that will replace
                            these are in progress

Prototype assembled 2026-07-07 for design review. Not for public
distribution.
